//
//  SF_GuidedMissile.h
//  SF_Project6
//
//  Created by JungHo Kim on 12. 10. 29..
//  Copyright (c) 2012년 frf1226@nate.com. All rights reserved.
//

#ifndef SF_Project6_SF_GuidedMissile_h
#define SF_Project6_SF_GuidedMissile_h

#include "SF_Item.h"

class SF_GuidedMissile : public SF_Item
{
private:
    
public:
    
};

#endif
