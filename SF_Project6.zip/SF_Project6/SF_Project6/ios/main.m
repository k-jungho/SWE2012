//
//  main.m
//  SF_Project6
//
//  Created by JungHo Kim on 12. 10. 25..
//  Copyright frf1226@nate.com 2012년. All rights reserved.
//

#import <UIKit/UIKit.h>

int main(int argc, char *argv[]) {
    
    NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
    int retVal = UIApplicationMain(argc, argv, nil, @"AppController");
    [pool release];
    return retVal;
}
